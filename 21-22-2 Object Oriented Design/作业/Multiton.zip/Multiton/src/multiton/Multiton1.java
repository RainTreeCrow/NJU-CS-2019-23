package multiton;
import java.util.*;

public class Multiton1 {
	private static int maxCount = 1;
	private Multiton1() { System.out.print("New instance!\n"); }
	private static class HolderClass {
		private static List instanceList = new ArrayList();
		static {
			for (int i = 0; i < maxCount; i++) {
				Multiton1 instance = new Multiton1();
				instanceList.add(instance);
			}
		}
	}
	public static void setMaxCount(int max) {
		maxCount = max;
	}
    public static Multiton1 getInstance() {
        int i = new Random().nextInt(maxCount);
        Multiton1 instance = (Multiton1)HolderClass.instanceList.get(i);
        System.out.println("Got Instance No." + (i + 1));
        return instance;
    }
}
