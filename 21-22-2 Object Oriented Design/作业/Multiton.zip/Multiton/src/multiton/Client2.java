package multiton;

public class Client2 {
	public static void main(String args[]) {
		Multiton2.setMaxCount(3);
		Multiton2 M1 = Multiton2.getInstance();
		Multiton2 M2 = Multiton2.getInstance();
		Multiton2 M3 = Multiton2.getInstance();
		Multiton2 M4 = Multiton2.getInstance();
		Multiton2 M5 = Multiton2.getInstance();
	}
}
