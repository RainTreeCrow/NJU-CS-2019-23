package multiton;

public class Client1 {
	public static void main(String args[]) {
		Multiton1.setMaxCount(10);
		Multiton1 M1 = Multiton1.getInstance();
		Multiton1 M2 = Multiton1.getInstance();
		Multiton1 M3 = Multiton1.getInstance();
		Multiton1 M4 = Multiton1.getInstance();
		Multiton1 M5 = Multiton1.getInstance();
	}
}
