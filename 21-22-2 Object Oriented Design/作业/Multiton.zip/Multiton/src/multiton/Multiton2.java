package multiton;
import java.util.*;

public class Multiton2 {
	private static int maxCount = 1;
	private static int currentCount = 0;
	private static List instanceList = new ArrayList();
	private Multiton2() { System.out.print("New instance!\n"); }
	public static void setMaxCount(int max) {
		maxCount = max;
	}
	synchronized public static Multiton2 getInstance() {
    	if (currentCount < maxCount) {
    		Multiton2 instance = new Multiton2();
			instanceList.add(instance);
    		System.out.println("Got Instance No." + (++currentCount));
			return instance;
    	}
    	else {
    		int i = new Random().nextInt(maxCount);
    		Multiton2 instance = (Multiton2)instanceList.get(i);
    		System.out.println("Got Instance No." + (i + 1));
    		return instance;
    	}
    }
}
