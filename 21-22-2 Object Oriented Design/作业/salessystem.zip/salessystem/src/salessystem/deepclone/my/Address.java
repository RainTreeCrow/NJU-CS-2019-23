package salessystem.deepclone.my;

public class Address {
	String street1;
	String city;
	String province;
	String country;
	String postcode;

	public void setStreet1(String street1) {
		this.street1 = street1;
	}

	public String getStreet1() {
		return this.street1;
	}
	
	public void setCity(String city) {
		this.city = city;
	}

	public String getCity() {
		return this.city;
	}
	
	public void setProvince(String province) {
		this.province = province;
	}

	public String getProvince() {
		return this.province;
	}
	
	public void setCountry(String country) {
		this.country = country;
	}

	public String getCountry() {
		return this.country;
	}
	
	public void setPostCode(String postcode) {
		this.postcode = postcode;
	}

	public String getPostcode() {
		return this.postcode;
	}
	
	public Address deepClone() {
		Address clone = new Address();
		clone.setStreet1(this.street1);
		clone.setCity(this.city);
		clone.setProvince(this.province);
		clone.setCountry(this.country);
		clone.setPostCode(this.postcode);
		return clone;
	}
}
