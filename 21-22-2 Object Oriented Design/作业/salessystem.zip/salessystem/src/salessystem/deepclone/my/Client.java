package salessystem.deepclone.my;

public class Client {
	public static void main(String args[]) {
		Customer cus_previous, cus_new = null;
		cus_previous = new Customer();
		Address address = new Address();
		cus_previous.setAddress(address);
		try {
			cus_new = cus_previous.deepClone();	
		}
		catch(Exception e) {
			System.err.println("��¡ʧ�ܣ�");
		}
		System.out.println("Customer�Ƿ���ͬ�� " + (cus_previous == cus_new));
		//System.out.println("Name�Ƿ���ͬ�� " + (cus_previous.getName() == cus_new.getName()));
		//System.out.println("Age�Ƿ���ͬ�� " + (cus_previous.getAge() == cus_new.getAge()));
		//System.out.println("Gender�Ƿ���ͬ�� " + (cus_previous.getGender() == cus_new.getGender()));
		System.out.println("Address�Ƿ���ͬ�� " + (cus_previous.getAddress() == cus_new.getAddress()));
		//System.out.println("City�Ƿ���ͬ�� " + (cus_previous.getAddress().getCity() == cus_new.getAddress().getCity()));
	}
}
