package salessystem.deepclone.serializable;

import java.io.*;

public class Customer implements Serializable {
	String name;
	int age;
	Boolean gender;
	Address address;
	
	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return (this.name);
	}
	
	public void setAge(int age) {
		this.age = age;
	}

	public int getAge() {
		return (this.age);
	}
	
	public void setGender(Boolean gender) {
		this.gender = gender;
	}

	public Boolean getGender() {
		return (this.gender);
	}
	
	public void setAddress(Address address) {
		this.address = address;
	}

	public Address getAddress() {
		return (this.address);
	}
	
	public Customer deepClone() throws IOException, ClassNotFoundException, OptionalDataException {
		ByteArrayOutputStream bao=new ByteArrayOutputStream();
		ObjectOutputStream oos=new ObjectOutputStream(bao);
		oos.writeObject(this);
		ByteArrayInputStream bis=new ByteArrayInputStream(bao.toByteArray());
		ObjectInputStream ois=new ObjectInputStream(bis);
		return (Customer)ois.readObject();
	}
}
