package salessystem.shallowclone.my;

public class Customer {
	String name;
	int age;
	Boolean gender;
	Address address;
	
	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return (this.name);
	}
	
	public void setAge(int age) {
		this.age = age;
	}

	public int getAge() {
		return (this.age);
	}
	
	public void setGender(Boolean gender) {
		this.gender = gender;
	}

	public Boolean getGender() {
		return (this.gender);
	}
	
	public void setAddress(Address address) {
		this.address = address;
	}

	public Address getAddress() {
		return (this.address);
	}
	
	public Customer clone() {
		Customer clone = new Customer();
		clone.setName(this.name);
		clone.setAge(this.age);
		clone.setGender(this.gender);
		clone.setAddress(this.address);
		return clone;
	}
}
