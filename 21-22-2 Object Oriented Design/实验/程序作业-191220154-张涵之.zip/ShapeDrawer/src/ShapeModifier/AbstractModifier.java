package ShapeModifier;

import Shapes.AbstractShape;

public abstract class AbstractModifier {
	public abstract AbstractShape Modify(AbstractShape shape);
}
