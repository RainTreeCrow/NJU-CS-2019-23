﻿#include <iostream>
#include <stdio.h>
#include <unistd.h>
#include <pwd.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <string.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>
using namespace std;

void ls() {
	char path[100];
	getcwd(path, 100);
	struct dirent* filename;
	DIR* dir = opendir(path);
	while (filename = readdir(dir)) {
		char* file = filename->d_name;
		if (file[0] != '.')
			cout << file << ' ';
	}
	cout << endl;
}

void cp(char* file1, char* file2) {
	bool special = false;
	char path1[100];
	getcwd(path1, 100);
	strcat(path1, "/");
	struct dirent* file;
	DIR* dir1 = opendir(path1);
	while (file = readdir(dir1)) {
		char*address = file->d_name;
		if ((strcmp(address, file1) == 0) && (file->d_type == 4)) {
			cout << "cp: -r not specified; omitting directory \'" << file1 << "\'" << endl;
			special = true;
			break;
		}
	}
	if (special == false) {
		dir1 = opendir(path1);
		while (file = readdir(dir1)) {
			char*address = file->d_name;
			if ((strcmp(address, file2) == 0) && (file->d_type == 4)) {
				strcat(path1, file2);
				if (path1[strlen(path1) - 1] != '/')
					strcat(path1, "/");
				strcat(path1, file1);
				cp(file1, path1);
				special = true;
				break;
			}
		}
	}
	if (special == false) {
		FILE* f1 = NULL;
		f1 = fopen(file1, "r");
		if (f1 == NULL)
			cout << "cp: 无法获取\'" << file1 << "\'的文件状态(stat): 没有那个文件或目录" << endl;
		else {
			char ch;
			FILE* f2 = fopen(file2, "w");
			while ((ch = fgetc(f1)) != EOF)
				fputc(ch, f2);
			fclose(f2);
			fclose(f1);
		}
	}
}

void cp_r(char* path1, char* path2, char* file1) {
	struct dirent* file;
	DIR* dir = opendir(path1);
	if (dir == NULL)
		cout << "cp: 无法获取\'" << file1 << "\'的文件状态(stat): 没有那个文件或目录" << endl;
	else {
		while (file = readdir(dir)) {
			if (file->d_type == 4) {
				char* address = file->d_name;
				if (address[0] != '.') {
					char temp1[100], temp2[100];
					strcpy(temp1, path1);
					strcat(temp1, address);
					if (temp1[strlen(temp1) - 1] != '/')
						strcat(temp1, "/");
					strcpy(temp2, path2);
					strcat(temp2, address);
					if (temp2[strlen(temp2) - 1] != '/')
						strcat(temp2, "/");
					if (!opendir(temp2))
						mkdir(temp2, 0777);
					cp_r(temp1, temp2, address);
				}
			}
			else {
				char* address = file->d_name;
				char temp1[100], temp2[100];
				strcpy(temp1, path1);
				strcat(temp1, address);
				strcpy(temp2, path2);
				strcat(temp2, address);
				cp(temp1, temp2);
			}

		}
	}
}

void cmp(char* file1, char* file2) {
	FILE* f1 = NULL;
	f1 = fopen(file1, "r");
	if (f1 == NULL)
		cout << "cmp: " << file1 << ": 没有那个文件或目录" << endl;
	else {
		FILE* f2 = fopen(file2, "r");
		if (f2 == NULL)
			cout << "cmp: " << file2 << ": 没有那个文件或目录" << endl;
		else {
			char ch1, ch2;
			bool b1 = false, b2 = true;
			int line = 1, byte = 1;
			while ((ch1 = fgetc(f1)) != EOF && (ch2 = fgetc(f2)) != EOF) {				
				if (ch1 != ch2)
					break;
				else if (ch1 == EOF) {
					b1 = true;
					break;
				}
				else if (ch2 == EOF) {
					b2 = true;
					break;
				}
				else if (ch1 == '\n' && ch2 == '\n')
					line += 1;
				byte += 1;
			}
			if (b1)
				cout << "cmp: EOF on " << file1 << " after byte " << byte << " line " << line << endl;
			else if (b2)
				cout << "cmp: EOF on " << file2 << " after byte " << byte << " line " << line << endl;
			else if ((ch1 = fgetc(f1)) != EOF || (ch2 = fgetc(f2) != EOF))
				cout << file1 << ' ' << file2 << "不同: 第 " << byte << " 字节, 第 " << line << " 行" << endl;
			fclose(f2);
			fclose(f1);
		}
	}
}

void wc_c(char file[][10], int var) {
	int total = 0;
	for (int i = 2; i <= var; i++) {
		FILE* f = NULL;
		f = fopen(file[i], "r");
		if (f == NULL)
			cout << "wc: " << file[i] << ": 没有那个文件或目录" << endl;
		else {
			int count = 0;
			char ch;
			while ((ch = fgetc(f)) != EOF)
				count += 1;
			fclose(f);
			total += count;
			cout << count << ' ' << file[i] << endl;
		}
	}
	if (var > 2)
		cout << total << " 总用量" << endl;
}

void wc_w(char file[][10], int var) {
	int total = 0;
	for (int i = 2; i <= var; i++) {
		FILE* f = NULL;
		f = fopen(file[i], "r");
		if (f == NULL)
			cout << "wc: " << file[i] << ": 没有那个文件或目录" << endl;
		else {
			int count = 0;
			char ch, temp = ' ';
			while ((ch = fgetc(f)) != EOF) {
				if (ch == ' ' || ch == '\n' || ch == '\t' || ch == '\r')
					if (temp != ' ' && temp != '\n' && temp != '\t' && temp != '\r')
						count += 1;
				temp = ch;
			}
			fclose(f);
			total += count;
			cout << count << ' ' << file[i] << endl;
		}
	}
	if (var > 2)
		cout << total << " 总用量" << endl;
}

void wc_l(char file[][10], int var) {
	int total = 0;
	for (int i = 2; i <= var; i++) {
		FILE* f = NULL;
		f = fopen(file[i], "r");
		if (f == NULL)
			cout << "wc: " << file[i] << ": 没有那个文件或目录" << endl;
		else {
			int count = 0;
			char ch;
			while ((ch = fgetc(f)) != EOF) {
				if (ch == '\n')
					count += 1;
			}
			fclose(f);
			total += count;
			cout << count << ' ' << file[i] << endl;
		}
	}
	if (var > 2)
		cout << total << " 总用量" << endl;
}

void wc(char file[][10], int var) {
	int c_total = 0, w_total = 0, l_total = 0;
	for (int i = 1; i <= var; i++) {
		FILE* f = NULL;
		f = fopen(file[i], "r");
		if (f == NULL)
			cout << "wc: " << file[i] << ": 没有那个文件或目录" << endl;
		else {
			int c_count = 0, w_count = 0, l_count = 0;
			char ch, temp = ' ';
			while ((ch = fgetc(f)) != EOF) {
				c_count += 1;
				if (ch == '\n')
					l_count += 1;
				if (ch == ' ' || ch == '\n' || ch == '\t' || ch == '\r')
					if (temp != ' ' && temp != '\n' && temp != '\t' && temp != '\r')
						w_count += 1;
				temp = ch;
			}
			fclose(f);
			c_total += c_count;
			w_total += w_count;
			l_total += l_count;
			cout << l_count << ' ' << w_count << ' ' << c_count << ' ' << file[i] << endl;
		}
	}
	if (var > 1)
		cout << l_total << ' ' << w_total << ' ' << c_total << " 总用量" << endl;
}

void cat(char file[][10], int var) {
	for (int i = 1; i <= var; i++) {
		FILE* f = NULL;
		f = fopen(file[i], "r");
		if (f == NULL)
			cout << "cat: " << file[i] << ": 没有那个文件或目录" << endl;
		else {
			char ch, temp[200];
			int i = 0;
			while ((ch = fgetc(f)) != EOF) {
				if (ch == '\n') {
					temp[i] = '\0';
					cout << temp << endl;
					i = 0;
				}
				else if (i == 198) {
					temp[199] = '\0';
					cout << temp;
					i = 0;
				}
				else {
					temp[i] = ch;
					i += 1;
				}
			}
		}
	}
}

void man_helper(char* command) {
	if (strcmp(command, "ls") == 0) {
		cout << "NAME" << endl;
		cout << "\tls - list directory contents\n" << endl;
		cout << "SYNOPSIS" << endl;
		cout << "\tls [OPTION]... [FILE]...\n" << endl;
		cout << "DESCRIPTION" << endl;
		cout << "\tList information about the FILEs (the current directory by default).\n" << endl;
		cout << "\tMandatory arguments to long options are mandatory for short options too.\n" << endl;
		cout << "AUTHOR" << endl;
		cout << "\tWritten by Zhang Hanzhi.\n" << endl;
	}
	else if (strcmp(command, "cp") == 0) {
		cout << "NAME" << endl;
		cout << "\tcp - copy files and directories\n" << endl;
		cout << "SYNOPSIS" << endl;
		cout << "\tcp[OPTION]...[-T] SOURCE DEST" << endl;
		cout << "\tcp[OPTION]... SOURCE... DIRECTORY\n" << endl;
		cout << "DESCRIPTION" << endl;
		cout << "\tCopy SOURCE to DEST, or multiple SOURCE(s) to DIRECTORY.\n" << endl;
		cout << "\tMandatory arguments to long options are mandatory for short options too.\n" << endl;
		cout << "\t-R, -r, --recursive" << endl;
		cout << "\t\tcopy directories recursively" << endl;
		cout << "AUTHOR" << endl;
		cout << "\tWritten by Zhang Hanzhi.\n" << endl;
	}
	else if (strcmp(command, "cmp") == 0) {
		cout << "NAME" << endl;
		cout << "\tcmp - compare two files byte by byte\n" << endl;
		cout << "SYNOPSIS" << endl;
		cout << "\tcmp [OPTION]... FILE1 [FILE2]\n" << endl;
		cout << "DESCRIPTION" << endl;
		cout << "\tCompare two files byte by byte.\n" << endl;
		cout << "\tMandatory arguments to long options are mandatory for short options too.\n" << endl;
		cout << "AUTHOR" << endl;
		cout << "\tWritten by Zhang Hanzhi.\n" << endl;
	}
	else if (strcmp(command, "wc") == 0) {
		cout << "NAME" << endl;
		cout << "\twc - print newline, word, and byte counts for each file\n" << endl;
		cout << "SYNOPSIS" << endl;
		cout << "\twc [OPTION]... [FILE]...\n" << endl;
		cout << "DESCRIPTION" << endl;
		cout << "\tPrint newline, word, and byte counts for each FILE, and a total line if more than one FILE is specified." << endl;
		cout << "\tA word is a non-zero-length sequence of characters delimited by white space.\n" << endl;
		cout << "\tWith no FILE, or when FILE is -, read standard input.\n" << endl;
		cout << "\tThe options below may be used to select which counts are printed, always in the following order:" << endl;
		cout <<	"\tnew-line, word, character, byte, maximum line length.\n" << endl;
		cout << "\t-c, --bytes" << endl;
		cout << "\t\tprint the byte counts\n" << endl;
		cout << "\t-l, --lines" << endl;
		cout << "\t\tprint the newline counts\n" << endl;
		cout << "\t-w, --words" << endl;
		cout << "\t\tprint the word counts\n" << endl;
		cout << "AUTHOR" << endl;
		cout << "\tWritten by Zhang Hanzhi.\n" << endl;
	}
	else if (strcmp(command, "cat") == 0) {
		cout << "NAME" << endl;
		cout << "\tcat - concatenate files and print on the standard output\n" << endl;
		cout << "SYNOPSIS" << endl;
		cout << "\tcat [OPTION]... [FILE]...\n" << endl;
		cout << "DESCRIPTION" << endl;
		cout << "\tConcatenate FILE(s) to standard output.\n" << endl;
		cout << "\tWith no FILE, or when FILE is -, read standard input.\n" << endl;
		cout << "EXAMPLES" << endl;
		cout << "cat    Copy standard input to standard output.\n" << endl;
		cout << "AUTHOR" << endl;
		cout << "\tWritten by Zhang Hanzhi.\n" << endl;
	}
	else if (strcmp(command, "man") == 0) {
		cout << "名称" << endl;
		cout << "\tman - 在线参考手册的接口\n" << endl;
		cout << "概述" << endl;
		cout << "\tman [-C 文件] [-d] [-D] [--warnings[=警告]] [-R 编码] [-L 区域] [-m 系统[,...]] [-M 路径] [-S 列表]" << endl;
		cout << "\t[-e 扩展][-i|-I] [--regex|--wildcard] [--names-only] [-a] [-u] [--no-subpages] [-P  分页程序] [-r  提示]" << endl;
		cout << "\t[-7] [-E 编码] [--no-hyphenation] [--no-justification] [-p 字符串] [-t] [-T[设备]] [-H[浏览器]]" << endl;
		cout << "\t[-X[dpi]][-Z] [[章节]页[.章节] ...] ...\n" << endl;
		cout << "描述" << endl;
		cout << "\tman 是系统的手册分页程序。指定给 man 的 页 选项通常是程序、工具或函数名。程序将显示每一个找到的相关" << endl;
		cout << "\t手册页。如果指定了 章节，man 将只在手册的指定 章节 搜索。默认将按预定的顺序查找所有可用的 章节(默认是" << endl;
		cout << "\t\"1 n l 8 3 2 3posix 3pm 3perl 3am 5 4 9 6 7\"，除非被 /etc/manpath.config 中的 SECTION 指令覆盖)，并" << endl;
		cout << "\t只显示找到的第一个 页，即使多个 章节 中都有这个 页面。\n" << endl;
		cout << "\t下表显示了手册的 章节 号及其包含的手册页类型。\n" << endl;
		cout << "\t1  可执行程序或 shell 命令" << endl;
		cout << "\t2  系统调用(内核提供的函数)" << endl;
		cout << "\t3  库调用(程序库中的函数)" << endl;
		cout << "\t4  特殊文件(通常位于 /dev)" << endl;
		cout << "\t5  文件格式和规范，如 /etc/passwd" << endl;
		cout << "\t6  游戏" << endl;
		cout << "\t7  杂项(包括宏包和规范，如 man(7)，groff(7))" << endl;
		cout << "\t8  系统管理命令(通常只针对 root 用户)" << endl;
		cout << "\t9  内核例程[非标准\n" << endl;
		cout << "\t一个手册 页面 包含若干个小节。\n" << endl;
		cout << "\t程序和函数说明应该是一个可以匹配所有可能用法的模式(pattern)。有些情况下，建议按此手册页 概述(SYNOPSIS)" << endl;
		cout << "\t小节所显示的分别陈述几种互斥的用法。\n" << endl;
		cout << "示例" << endl;
		cout << "\tman ls" << endl;
		cout << "\t显示 项目(程序) ls 对应的手册页\n" << endl;
		cout << "概述" << endl;
		cout << "\tman 有许多选项供用户灵活使用。搜索路径、章节顺序、输出处理器和其他行为和操作均可更改。\n" << endl;
		cout << "\t如果所需的页面有您的 区域 对应的版本，它会替代标准的(通常为美国英语)手册页显示。\n" << endl;
		cout << "默认值" << endl;
		cout << "\t如果可以生成 cat 文件(相应的 cat 目录存在并有正确的权限)，man 会在后台压缩并保存 cat 文件。\n" << endl;
		cout << "\t如果以上方法没有提供过滤程序信息，将使用默认程序集。\n" << endl;
		cout << "选项" << endl;
		cout << "\t非参数的选项如果在命令行和/或 $MANOPT 重复指定，不会产生问题。" << endl;
		cout << "\t对于需要参数的选项，每次重复将覆盖上个参数值。\n" << endl;
	}
	else if (strcmp(command, "sh") == 0)	{
		cout << "NAME" << endl;
		cout << "\tdash — command interpreter (shell)\n" << endl;
		cout << "SYNOPSIS" << endl;
		cout << "\tdash [-aCefnuvxIimqVEbp] [+aCefnuvxIimqVEbp] [-o option_name] [+o option_name]" << endl;
		cout <<	"\t\t[command_file[argument ...]]" << endl;
		cout << "\tdash -c [-aCefnuvxIimqVEbp] [+aCefnuvxIimqVEbp] [-o option_name] [+o option_name] command_string" << endl;
		cout << "\t\t[command_name[argument ...]]" << endl;
		cout << "\tdash -s [-aCefnuvxIimqVEbp] [+aCefnuvxIimqVEbp] [-o option_name] [+o option_name] [argument ...]\n" << endl;
		cout << "DESCRIPTION" << endl;
		cout << "\tdash is the standard command interpreter for the system." << endl;
		cout << "\tThis man page is not intended to be a tutorial or a complete specification of the shell.\n" << endl;
	}
}

void man(char command[][10], int var) {
	bool flag = false;
	if ((strcmp(command[1], "ls") != 0) && (strcmp(command[1], "cp") != 0) && (strcmp(command[1], "cmp") != 0)
		&& (strcmp(command[1], "wc") != 0) && (strcmp(command[1], "cat") != 0) &&
		(strcmp(command[1], "man") != 0) && (strcmp(command[1], "sh") != 0))
		cout << "没有 " << command[1] << " 的手册页条目" << endl;
	else {
		man_helper(command[1]);
		flag = true;
	}
	for (int i = 2; i <= var; i++) {
		if ((strcmp(command[i], "ls") != 0) && (strcmp(command[i], "cp") != 0) && (strcmp(command[i], "cmp") != 0)
			&& (strcmp(command[i], "wc") != 0) && (strcmp(command[i], "cat") != 0) &&
				(strcmp(command[i], "man") != 0) && (strcmp(command[i], "sh") != 0)) {
			cout << "没有 " << command[i] << " 的手册页条目" << endl;
			continue;
		}
		if (flag) {
			cout << "--Man-- 下一页: " << command[i] << " [ 查看 (r) | 跳过 (d) | 退出 (c) ]" << endl;
			char ch = getc(stdin);
			while ((ch != 'r') && (ch != 'd') && (ch != 'c'))
				ch = getc(stdin);
			if (ch == 'r')
				man_helper(command[i]);
			else if (ch == 'd')
				continue;
			else if (ch == 'c')
				break;
		}
		else {
			man_helper(command[i]);
			flag = true;
		}
	}
}

void process(char* command);

void sh(char* test_sh) {
	FILE* f = NULL;
	f = fopen(test_sh, "r");
	if (f == NULL)
		cout << "sh: 0: Can\'t open "<< test_sh << endl;
	else {
		char ch, temp[100];
		int i = 0;
		while ((ch = fgetc(f)) != EOF) {
			if (ch == '\n') {
				temp[i] = '\0';
				process(temp);
				i = 0;
			}
			else {
				temp[i] = ch;
				i += 1;
			}
		}
		fclose(f);
	}
}

void process(char* command) {
	char buffer[10][10];
	for (int i = 0; i < 10; i++)
		memset(buffer[i], 0, 10);
	int var = 0, len = 0;
	for (int i = 0; command[i] != '\0'; i++) {
		if ((command[i] == ' ') || (command[i] == '\t') || (command[i] == '\n')) {
			if ((i > 1) && (command[i - 1] != ' ') && (command[i - 1] != '\t') && (command[i - 1] != '\n')) {
				buffer[var][len] = '\0';
				var += 1;
				len = 0;
			}
		}
		else {
			buffer[var][len] = command[i];
			len += 1;
		}
	}
	buffer[var][len] = '\0';
	if ((buffer[0][0] == '\0') || (strcmp(buffer[0], " ") == 0) ||
		(strcmp(buffer[0], "\t") == 0) || (strcmp(buffer[0], "\n") == 0));
	else if (strcmp(buffer[0], "ls") == 0)
		ls();
	else if (strcmp(buffer[0], "cp") == 0) {
		if (strcmp(buffer[1], "-r") == 0) {
			if (var > 3)
				cout << "cp: 目标\'" << buffer[var] << "\' 不是目录" << endl;
			else {
				char path1[100], path2[100];
				getcwd(path1, 100);
				strcat(path1, "/");
				strcpy(path2, path1);
				strcat(path1, buffer[2]);
				if (path1[strlen(path1) - 1] != '/')
					strcat(path1, "/");
				strcat(path2, buffer[3]);
				if (path2[strlen(path2) - 1] != '/')
					strcat(path2, "/");
				if (!opendir(path2))
					mkdir(path2, 0777);
				cp_r(path1, path2, buffer[2]);
			}
		}
		else if (buffer[1][0] == '-') {
			cout << "cp: 不适用的选项 -" << buffer[1] << endl;
			cout << "Try \'cp --help\' for more information." << endl;
		}
		else {
			if (var > 2)
				cout << "cp: 目标\'" << buffer[var] << "\' 不是目录" << endl;
			else
				cp(buffer[1], buffer[2]);
		}
	}
	else if (strcmp(buffer[0], "cmp") == 0) {
		if (var > 2) {
			cout << "cmp: 无效的 --ignore-initial 值 \'" << buffer[3] << '\'' << endl;
			cout << "请尝试 \"cmp --help\", 以获得更多信息。" << endl;
		}
		else
			cmp(buffer[1], buffer[2]);
	}
	else if (strcmp(buffer[0], "wc") == 0) {
		if (strcmp(buffer[1], "-c") == 0)
			wc_c(buffer, var);
		else if (strcmp(buffer[1], "-w") == 0)
			wc_w(buffer, var);
		else if (strcmp(buffer[1], "-l") == 0)
			wc_l(buffer, var);
		else if (buffer[1][0] == '-') {
			cout << "cp: 不适用的选项 -" << buffer[1] << endl;
			cout << "Try \'wc --help\' for more information." << endl;
		}
		else
			wc(buffer, var);
	}
	else if (strcmp(buffer[0], "cat") == 0)
		cat(buffer, var);
	else if (strcmp(buffer[0], "man") == 0)
		man(buffer, var);
	else if (strcmp(buffer[0], "sh") == 0)
		sh(buffer[1]);
	else
		cout << "bash: " << buffer[0] << ": 未找到命令" << endl;
}

void interact() {
	uid_t userid;
	struct passwd* pwd;
	userid = getuid();
	pwd = getpwuid(userid);
	char username[128];
	gethostname(username, 128);
	char path[100];
	getcwd(path, 100);
	int temp = 6 + strlen(pwd->pw_name);
	char c_path[100];
	int i;
	for (i = temp; path[i] != '\0'; i++)
		c_path[i - temp] = path[i];
	c_path[i - temp] = '\0';
	while (1) {
		cout << "\033[1m\033[37m" << "MYSHELL" << "\033[1m\033[32m" << pwd->pw_name << "@" << username << "\033[0m" << ":" << "\033[1m\033[34m" << "~" << c_path << "\033[0m" << "$ ";
		char command[100];
		cin.getline(command, 100);
		if (strcmp(command, "exit") == 0)
			break;
		else
			process(command);
	}
}

int main()
{
	interact();
	return 0;
}
