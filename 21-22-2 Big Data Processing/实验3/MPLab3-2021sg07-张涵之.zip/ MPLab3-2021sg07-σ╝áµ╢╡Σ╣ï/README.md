# README

## 任务一 UniversityCountry

**执行命令：**`hadoop jar exp3_UniversityCountry.jar ReduceJoin /data/2022s/hive_join /user/2021sg07/exp3/UniversityCountry`



## 任务二 CourseUniversity

**执行命令：**`hadoop jar exp3_CourseUniversity.jar MapJoin /data/2022s/hive_join /user/2021sg07/exp3/CourseUniversity`