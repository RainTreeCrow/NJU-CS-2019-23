#include "lib.h"
#include "types.h"

//Philosopher

#define N 5
sem_t forks[N];
	
void philosopher(int i, sem_t forks[]) {
	int id = getpid();
	while(1) {
		if (i % 2 == 0) {
			sem_wait(&forks[i]);
			//printf("Philosopher %d pick up fork %d\n", id, i); 
			sleep(128);
			sem_wait(&forks[(i + 1) % N]);
			//printf("Philosopher %d pick up fork %d\n", id, (i + 1) % N);
			sleep(128);
		}
		else {
			sem_wait(&forks[(i + 1) % N]);
			//printf("Philosopher %d pick up fork %d\n", id, (i + 1) % N);
			sleep(128);
			sem_wait(&forks[i]);
			//printf("Philosopher %d pick up fork %d\n", id, i);
			sleep(128);
		}
		printf("Philosopher %d: eat\n", id);
		sleep(128);
		printf("Philosopher %d: think\n", id);
		sleep(128);
		sem_post(&forks[i]);
		//printf("Philosopher %d put down fork %d\n", id, i);
		sleep(128);
		sem_post(&forks[(i + 1) % N]);
		//printf("Philosopher %d put down fork %d\n", id, (i + 1) % N);
		sleep(128);
	}
}

//Bounded Buffer

sem_t mutex;
sem_t fullbuffer;
sem_t emptybuffer;

void deposit() {
	int id = getpid();
	while(1) {
		sem_wait(&emptybuffer);
		sleep(128);
		sem_wait(&mutex);
		sleep(128);
		printf("Producer %d: produce\n", id);
		sleep(128);
		sem_post(&mutex);
		sleep(128);
		sem_post(&fullbuffer);
		sleep(128);
	}
}

void remove() {
	while(1) {
		sem_wait(&fullbuffer);
		sleep(128);
		sem_wait(&mutex);
		sleep(128);
		printf("Consumer: consume\n");
		sleep(128);
		sem_post(&mutex);
		sleep(128);
		sem_post(&emptybuffer);
		sleep(128);
	}
}

//Reader Writer (did not succeed)

sem_t writemutex;
int rcount;
sem_t countmutex;

void write() {
	int id = getpid();
	while(1) {
		sem_wait(&writemutex);
		sleep(128);
		printf("Writer %d: write\n", id);
		sleep(128);
		sem_post(&writemutex);
		sleep(128);
	}
}

void read() {
	int id = getpid();
	while(1) {
		sem_wait(&countmutex);
		sleep(128);
		if (rcount == 0) {
 			sem_wait(&writemutex);
			sleep(128);
		}
		rcount++;
		sleep(128);
		sem_post(&countmutex);
		sleep(128);
		printf("Reader %d: read, total %d reader\n", id, rcount);
		sleep(128);
		sem_wait(&countmutex);
		sleep(128);
		rcount--;
		sleep(128);
		if (rcount == 0) {
			sem_post(&writemutex);
			sleep(128);
		}
		sem_post(&countmutex);
		sleep(128);
	}
}

int uEntry(void) {
	// For lab4.1
	// Test 'scanf'
	int dec = 0;
	int hex = 0;
	char str[6];
	char cha = 0;
	int ret = 0;
	while(1){
		printf("Input:\" Test %%c Test %%6s %%d %%x\"\n");
		ret = scanf(" Test %c Test %6s %d %x", &cha, str, &dec, &hex);
		printf("Ret: %d; %c, %s, %d, %x.\n", ret, cha, str, dec, hex);
		if (ret == 4)
			break;
	}
	
	// For lab4.2
	// Test 'Semaphore'
	int i = 4;
	sem_t sem;
	printf("Father Process: Semaphore Initializing.\n");
	ret = sem_init(&sem, 2);
	if (ret == -1) {
		printf("Father Process: Semaphore Initializing Failed.\n");
		exit();
	}
	ret = fork();
	if (ret == 0) {
		while( i != 0) {
			i --;
			printf("Child Process: Semaphore Waiting.\n");
			sem_wait(&sem);
			printf("Child Process: In Critical Area.\n");
		}
		printf("Child Process: Semaphore Destroying.\n");
		sem_destroy(&sem);
		exit();
	}
	else if (ret != -1) {
		while( i != 0) {
			i --;
			printf("Father Process: Sleeping.\n");
			sleep(128);
			printf("Father Process: Semaphore Posting.\n");
			sem_post(&sem);
		}
		printf("Father Process: Semaphore Destroying.\n");
		sem_destroy(&sem);
		exit();
	}

	// For lab4.3
	// TODO: You need to design and test the philosopher problem.
	// Note that you can create your own functions.
	// Requirements are demonstrated in the guide.

	//Philosopher (finished)
	/*for (int i = 0; i < N; i++)
		sem_init(&forks[i], 1);
	for (int i = 0; i < 5; ++i) {
		if (fork() == 0) {
			philosopher(i, forks);
			
		}
	}
	exit();
	for (int i = 0; i < N; i++)
		sem_destroy(&forks[i]);*/

	//Bounded Buffer (finished)

	/*sem_init(&mutex, 1);
	sem_init(&fullbuffer, 0);
	sem_init(&emptybuffer, 4);
	for (int i = 0; i < 4; i++) {
		if (fork() == 0)
			deposit();
	}
	if (fork() == 0)
		remove();
	exit();
	sem_destroy(&mutex);
	sem_destroy(&fullbuffer);
	sem_destroy(&emptybuffer);*/

	//Reader Writer (unfinished)

	/*sem_init(&writemutex, 1);
	rcount = 0;
	sem_init(&countmutex, 1);
	for (int i = 0; i < 3; i++) {
		if (fork() == 0)
			write();
	}
	for (int i = 0; i < 3; i++) {
		if (fork() == 0)
			read();
	}
	exit();
	sem_destroy(&writemutex);
	sem_destroy(&countmutex);*/

	while(1);
	return 0;
}
