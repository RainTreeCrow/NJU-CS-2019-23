//
//  main.cpp
//  fat12Image-rlt
//
//  Created by rxx on 2021/6/6.
//

#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>



#define DIRPATH "/Users/rxx/Desktop/program/arithmetic/fat12Image-rlt"



//boot sector 镜像标识文件
struct BootSector {
    char BS_jmpBoot [3];
    char BS_OEMName [8];
    char other[448];
    short  Overflag;
    short  BPB_BytsPerSec;    //每扇区字节数
    char   BPB_SecPerClus;    //每簇扇区数
    short  BPB_RsvdSecCnt;    //Boot记录占用的扇区数
    char   BPB_NumFATs;       //FAT表个数
    short  BPB_RootEntCnt;    //根目录最大文件数
    short  BPB_TotSec16;      //逻辑扇区总数
    char   BPB_Media;         //媒体描述符
    short  BPB_FATSz16;       //FAT扇区数
    short  BPB_SecPerTrk;     //每磁道扇区数
    short  BPB_NumHeads;      //磁头数(面数)
    int  BPB_HiddSec;       //隐藏扇区数
    int  BPB_TotSec32;      //如果BPB_FATSz16为0，该值为FAT扇区数
    char   BS_DrvNum;         //中断 13 的驱动器号
    char   BS_Reserved1;      //未使用区域
    char   BS_BootSig;        //扩展引导标记 (29h)
    int  BS_VolID;          //卷序列号
    char BS_VolLab [11];    //卷标, 必须 11 个字节
    char BS_FileSysType [8];//文件系统类型, 必须 8个字节

};


//镜像路径完整，去文件名，得到当前路径；复制文件路径只写相对路径，方便拼接
void writeFile(char* imagefilename,char* srcfilename){
    
    if (imagefilename == NULL || srcfilename == NULL ){
        return ;
    }
    
    
    if (access(imagefilename,0)==0){
        remove(imagefilename);
    }
    
    char cmdcreatedir1[250];
    sprintf(cmdcreatedir1, "hdiutil create -o %s -size 1.4m -layout SPUD -fs HFS+J",imagefilename);
    system(cmdcreatedir1);
    
    
//    # 挂载上面新建的 dmg 镜像到虚拟磁盘，载点为 install_build，之后会使用，需要对应
//    hdiutil attach ~/Desktop/Mojave.cdr.dmg -noverify -mountpoint /Volumes/install_build
    memset(cmdcreatedir1, 0, 250);
    sprintf(cmdcreatedir1, "hdiutil attach %s -noverify -mountpoint /Volumes/install_build",imagefilename);
    system(cmdcreatedir1);
    
    
    //得到文件路径
    char tmpSrcdir[240] ;
    memset(tmpSrcdir, 0, 240);
    int has_ = 0;
    for (int i=strlen(srcfilename)-1; i>=0 ; i--) {
        //排除最后一个/
        if (srcfilename[i] == '/') {
            has_ = 1;
        }
        if (has_) {
            tmpSrcdir[i] = srcfilename[i];
        }
    }
    
    char tmpMakeDir[240] ;
    memset(tmpMakeDir, 0, 240);
    sprintf(tmpMakeDir, "mkdir /Volumes/install_build/%s", tmpSrcdir);
    system("mkdir /Volumes/install_build/demo");
    
    //得到文件路径
    char tmpSrcName[240] ;
    memset(tmpSrcName, 0, 240);
     has_ = 0;
    for (int i=strlen(imagefilename)-1; i>=0 ; i--) {
        //排除最后一个/
        if (imagefilename[i] == '/') {
            has_ = 1;
        }
        if (has_) {
            tmpSrcName[i] = imagefilename[i];
        }
    }
    
    //拼接路径
    char tmpSrcName2[240] ;
    memset(tmpSrcName2, 0, 240);
    sprintf(tmpSrcName2, "%s%s",tmpSrcName,srcfilename);

    
    memset(cmdcreatedir1, 0, 250);
    sprintf(cmdcreatedir1, "cp -R %s  /Volumes/install_build/%s",tmpSrcName2,tmpSrcdir);
    system(cmdcreatedir1);


    //# 取消挂载建立的dmg镜像，方便后续编辑，载点名已经从原来的install_build更改为Install macOS Mojave
    //hdiutil detach "/Volumes/Install macOS Mojave"
    memset(cmdcreatedir1, 0, 250);
    sprintf(cmdcreatedir1, "hdiutil detach \"/Volumes/install_build/\"");
    system(cmdcreatedir1);
    
}


void readFile(char* imagefilename,char* srcfilename ,char *localFileDir){
    
    if (imagefilename == NULL || srcfilename == NULL ){
        return ;
    }
    
    char cmdcreatedir[50];
    
    memset(cmdcreatedir, 0, 50);
    sprintf(cmdcreatedir, "hdiutil attach %s -noverify -mountpoint /Volumes/install_build",imagefilename);
    system(cmdcreatedir);
    
    memset(cmdcreatedir, 0, 50);
    sprintf(cmdcreatedir, "/Volumes/install_build%s",srcfilename);
    
    char tmpSrcName[50] ;
    memset(tmpSrcName, 0, 50);
    for (int i=0; i<strlen(srcfilename) ; i++) {
        if (srcfilename[i] != '.') {
            tmpSrcName[i] = srcfilename[i];
        }
    }
    
    if (access(tmpSrcName,00)==0){
        printf("没有找到文件");
    }
    
    memset(cmdcreatedir, 0, 50);
    sprintf(cmdcreatedir, "cp -R /Volumes/install_build/%s  %s", srcfilename, localFileDir);
    system(cmdcreatedir);
    
    
    memset(cmdcreatedir, 0, 50);
    sprintf(cmdcreatedir, "hdiutil detach \"/Volumes/install_build/\"");
    system(cmdcreatedir);
}

void formatDMG(char * dmgName,int length){
    
    //判断是否存在，如果有就先删除
    if (access(dmgName,0)==0){
        remove(dmgName);
    }
    
    //路径已经障碍了，直接生成文件就可以了
    FILE* fp = fopen(dmgName, "wb+");
    if(fp != NULL) {
        //根据预置的磁盘信息写入
        struct BootSector bootsector;
        bootsector.BS_jmpBoot[0] = 0xEB;
        bootsector.BS_jmpBoot[1] = 0x00;
        bootsector.BS_jmpBoot[2] = 0x90;
        strcpy(bootsector.BS_OEMName,"mkfs.fat");
        bootsector.BPB_BytsPerSec = 0x200;
        bootsector.BPB_SecPerClus = 0x01;
        bootsector.BPB_RsvdSecCnt = 0x0001;
        bootsector.BPB_NumFATs = 0x2;
        bootsector.BPB_RootEntCnt = 0x00E0;
        bootsector.BPB_TotSec16 = 0xB40;
        bootsector.BPB_Media = 0xF0;
        bootsector.BPB_FATSz16 =  0x0009;
        bootsector.BPB_SecPerTrk = 0x0012;
        bootsector.BPB_NumHeads = 0x0002;
        bootsector.BPB_HiddSec = 0x00000000;
        bootsector.BPB_TotSec32 = 0;
        bootsector.BS_DrvNum = 0;
        bootsector.BS_Reserved1 = 0;
        bootsector.BS_BootSig = 0x29;
        bootsector.BS_VolID = 0x5a114718;
        strcpy(bootsector.BS_VolLab, dmgName);
        strcpy(bootsector.BS_FileSysType, "FAT12   ");
        bootsector.Overflag = 0xAA55;
        fwrite(&bootsector.BS_jmpBoot[0], 1, 1, fp);
        fwrite(&bootsector.BS_jmpBoot[1], 1, 1, fp);
        fwrite(&bootsector.BS_jmpBoot[2], 1, 1, fp);
        fwrite(&bootsector.BS_OEMName, 8, 1, fp);
        fwrite(&bootsector.BPB_BytsPerSec, 2, 1, fp);
        fwrite(&bootsector.BPB_SecPerClus, 1, 1, fp);
        fwrite(&bootsector.BPB_RsvdSecCnt,2 , 1, fp);
        fwrite(&bootsector.BPB_NumFATs, 1, 1, fp);
        fwrite(&bootsector.BPB_RootEntCnt, 2, 1, fp);
        fwrite(&bootsector.BPB_TotSec16, 2, 1, fp);
        fwrite(&bootsector.BPB_Media, 1, 1, fp);
        fwrite(&bootsector.BPB_FATSz16, 2, 1, fp);
        fwrite(&bootsector.BPB_SecPerTrk, 2, 1, fp);
        fwrite(&bootsector.BPB_NumHeads, 2, 1, fp);
        fwrite(&bootsector.BPB_HiddSec, 4, 1, fp);
        fwrite(&bootsector.BPB_TotSec32, 4, 1, fp);
        fwrite(&bootsector.BS_DrvNum, 1, 1, fp);
        fwrite(&bootsector.BS_Reserved1, 1, 1, fp);
        fwrite(&bootsector.BS_BootSig, 1, 1, fp);
        fwrite(&bootsector.BS_VolID, 4, 1, fp);
        fwrite(&bootsector.BS_VolLab, 11, 1, fp);
        fwrite(&bootsector.BS_FileSysType, 8, 1, fp);
        fwrite(&bootsector.other, 448, 1, fp);
        fwrite(&bootsector.Overflag, 2, 1, fp);
        fseek(fp, length-1, SEEK_SET); // 将文件的指针 移至 指定大小的位置
        fputc(0, fp); // 在要指定大小文件的末尾随便放一个数据
        fclose(fp);
    }
    
}

int main(int argc,char** argv)
{
    //TODO:测试数据，模拟指令
    char tmpChar1[] = "fat";
    char tmpChar2[] = "-f";
    char tmpChar3[] = "-mi";
    char tmpChar4[] = "-mo";
    
    char tmpChar5[] = "/Users/rxx/Desktop/program/arithmetic/fat12Image-rlt/fat12Image-rlt/abc.dmg";//镜像地址名称
    char tmpChar9[] = "demo/aaa.txt";//读取源文件路径(代码的当前路径)
    char tmpChar10[] = "demo/aaa.txt";//从镜像拷贝到哪里
    char tmpChar6[] = "/Users/rxx/Desktop/program/arithmetic/fat12Image-rlt/fat12Image-rlt/";//代码路径，和系统保持一致
    
    //调试用代码
    char tmpChar7[] = "aaa.txt";
    char tmpChar8[] = "abc.dmg";
    
    //按需打开代码注释
    //格式化指令
//    argv[0] = tmpChar1;
//    argv[1] = tmpChar2;
//    argv[2] = tmpChar5;
    
    //复制进入
//    argv[0] = tmpChar1;
//    argv[1] = tmpChar3;
//    argv[2] = tmpChar5;
//    argv[3] = tmpChar9;
    
    //拷贝出
//    argv[0] = tmpChar1;
//    argv[1] = tmpChar4;
//    argv[2] = tmpChar5;
//    argv[3] = tmpChar10;
    

    char fformat[] = "-f";
    char fread[] = "-mo";
    char fwrite[] = "-mi";
    if (strcmp(fformat,argv[1]) == 0){
        formatDMG(argv[2],1474560);//2880 * 512 = 1474560
    }else if (strcmp(fread,argv[1]) == 0){
        readFile(argv[2],argv[3],tmpChar6);
    }else if(strcmp(fwrite,argv[1]) == 0){
        writeFile(argv[2],argv[3]);
    }
    return 0;
}
