//
//  main.cpp
//  findHardConnect
//
//  Created by rxx on 2021/6/5.
//

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <dirent.h>

//存储结构
typedef struct LINKLIST{
    char *fileName;
    int inodeNum;
    struct LINKLIST *next;//下一个硬链接大于等于2的文件
    struct LINKLIST *linkFile;//当前文件被硬链接的文件链表
};

//定义头节点，主定位节点，分支定位节点，尾部节点；
LINKLIST *linkListHead, *mainLinkListPosition, *linkFileLinkListPosition, *linkListEnd;

//初始化
void linkListInit(){
    linkListHead = (LINKLIST*)malloc(sizeof(LINKLIST));
    mainLinkListPosition = linkListHead;
    linkListEnd = linkListHead;
}

//添加主节点
void mainNodeIn(char *fileName, int inodeNum ){
    LINKLIST *tempNode = (LINKLIST*)malloc(sizeof(LINKLIST));
    char tmp[120] = "文件";
//    memset(tmp, '\0', sizeof(tmp));
    //不会c的深拷贝，暂时这样吧....
    char *ppp =(char *) malloc(strlen(tmp) + strlen(fileName)); ;//= strcat(tmp,
    sprintf(ppp, "%s%s", tmp, fileName);

    
    tempNode->fileName = ppp;
    tempNode->inodeNum = inodeNum;
    tempNode->next = NULL;
    tempNode->linkFile = NULL;
    if (mainLinkListPosition->fileName == NULL) {
        mainLinkListPosition = tempNode;
        linkListHead = mainLinkListPosition;
    } else{
        mainLinkListPosition->next = tempNode;
        mainLinkListPosition = tempNode;
    }
    
}

//添加硬链接相关节点
void linkFileNodeIn(LINKLIST *linkListPosition,char *fileName, int inodeNum ){
    LINKLIST *tempNode = (LINKLIST*)malloc(sizeof(LINKLIST));
    
    char tmp[120] = "文件";
//    memset(tmp, '\0', sizeof(tmp));
    //不会c的深拷贝，暂时这样吧....
    char *ppp =(char *) malloc(strlen(tmp) + strlen(fileName)); ;//= strcat(tmp,
    sprintf(ppp, "%s%s", tmp, fileName);
    
    tempNode->fileName = ppp;
    tempNode->inodeNum = inodeNum;
    tempNode->next = NULL;
    tempNode->linkFile = NULL;

    linkFileLinkListPosition = linkListPosition;

    while (linkFileLinkListPosition->linkFile != NULL) {
        linkFileLinkListPosition = linkFileLinkListPosition->linkFile;
    }
    //排除一下同文件
    if (linkFileLinkListPosition->linkFile == NULL) {
        if (strcmp(linkFileLinkListPosition->fileName, tempNode->fileName) != 0) {
            linkFileLinkListPosition->linkFile = tempNode;
        }
    }
    
    
}

//查找inodeindex的节点
LINKLIST * findInodeOf(int inode){
    LINKLIST *mainListP = linkListHead;
    while(mainListP != NULL && mainListP->fileName != NULL){
        if(mainListP->inodeNum == inode){
            return mainListP;
        }
        if (mainListP->next != NULL) {
            mainListP = mainListP->next;
        } else {
            mainListP = NULL;
        }
        
    }
    return NULL;
}


//遍历输出数据
void outPut(){
    LINKLIST *mainListP = linkListHead;

    while( mainListP != NULL && mainListP->fileName != NULL ){
        printf("硬链接大于等于2以上文件是：%s \n", mainListP->fileName );

        LINKLIST *branchListP = linkListHead;
        
        while(  branchListP != NULL && branchListP->fileName != NULL ) {
            
            printf("链接的文件有：%s \n",branchListP->fileName);
            
            if (branchListP->linkFile != NULL) {
                branchListP = branchListP->linkFile;
            } else{
                branchListP = NULL;
            }
            
        }
        if (mainListP->next != NULL) {
            mainListP = mainListP->next;
        } else {
            mainListP = NULL;
        }

    }
}

//读取元数据，入参：文件名，硬链接数量,文件索引号
void getStatData(char *argv[], int *linkNum, int *inodeNum) {
    struct stat b;
    
    //获取文件的元数据
    int s = stat(argv[1], &b);
    if(s == -1) {
        perror("stat");
        return ;
    }
    //输出文件的元数据
    printf("length:%hu\n", b.st_nlink);
    printf("inodeNum:%llu\n",b.st_ino);
    
    //TODO: 测试数据
    int tmpNlink = 2;b.st_nlink;//系统环境原因，暂时可以自己写个数字进去
    *linkNum = tmpNlink;
    int tmpIno = 3;b.st_ino;//系统环境原因，暂时可以自己写个数字进去
    *inodeNum = tmpIno;

    return;
}

//检测文件类型
int testdir(char *path)
{
    struct stat buf;
    if(lstat(path,&buf)<0) //不是目录
    {
        return 0;
    }
    if(S_ISDIR(buf.st_mode))//是目录
    {
        return 1; //directory
    }
    return 0;
}

int directory(char *path)//查找硬链接数大于等于2的文件
{
    DIR *db;
    char filename[128];
    struct dirent *p;
    db=opendir(path);
    if(db==NULL)return 0;
    memset(filename,0,128);
    while ((p=readdir(db)) != NULL)
    {
        if((strcmp(p->d_name,".")==0)||(strcmp(p->d_name,"..")==0))
            continue;
        else
        {
            sprintf(filename,"%s/%s",path,p->d_name);
            if(testdir(filename))
            {
                directory(filename);
            }
            else {
                //找到文件了
                char *tempWholeName = filename;
                char *wholeName = tempWholeName;
//                strcat( wholeName , path);
//                strcat( wholeName , "/");
//                strcat( wholeName , filename);
                printf("%s\n",filename);
                
                int linkNum = 0;
                int inodeNum = 0;
                getStatData(&wholeName, &linkNum, &inodeNum);
//                getStatData(wholeName, *linkNum, *inodeNum);
                
                if (linkNum != NULL) {
                    if(linkNum >= 2) {
                        mainNodeIn(wholeName, inodeNum);//生成主链表
                    }
                }
            }
        }
        memset(filename,0,64);
    }
    closedir(db);
    return 0;
}

int directory2(char *path)//查找相关的硬链接文件
{
    DIR *db;
    char filename[128];
    struct dirent *p;
    db=opendir(path);
    if(db==NULL)return 0;
    memset(filename,0,128);
    while ((p=readdir(db)))
    {
        if((strcmp(p->d_name,".")==0)||(strcmp(p->d_name,"..")==0))
            continue;
        else
        {
            sprintf(filename,"%s/%s",path,p->d_name);
            if(testdir(filename))
            {
                directory(filename);
            }
            else {
                //找到文件了
                char *tempWholeName = filename;
                char *wholeName = tempWholeName;
                printf("%s\n",filename);
                
                int linkNum = 0;
                int inodeNum = 0;
                getStatData(&wholeName, &linkNum, &inodeNum);
                
                LINKLIST *mainNode = findInodeOf(inodeNum);//查找是否有相同inode文件
                
                if(mainNode != NULL){
                    linkFileNodeIn(mainNode,wholeName, inodeNum );//有就放到branch链上
                }
                
            }
        }
        memset(filename,0,64);
    }
    closedir(db);
    return 0;
}


int main(int argc,char **argv)
{
    linkListInit();

    char *path="/Users/rxx/Desktop/program/arithmetic/findHardConnect/findHardConnect"; //要遍历的目录
    if(access(path,F_OK)==0&&testdir(path))
    {
        printf("is directory\n");
        directory(path);//遍历找出主文件
        directory2(path);//遍历找出硬链接文件
    }
    else printf("%s not exist\n",path);

    outPut();
    printf("");
}
