class LRUCache:
    ''' a Least Recently Used (LRU) cache
    具体逻辑省略...
    '''
    def __init__(self, capacity: int):
        ''' initiate the cache with a capacity '''
        self.cache = {}
        self.capacity = capacity

    def __getitem__(self, key):
        # some logic
        ...

    def __setitem__(self, key, value):
        # some logic
        ...

    def __contains__(self, k):
        # some logic
        ...

    def keys(self):
        return self.cache.keys()

    def values(self):
        return self.cache.values()

    def items(self):
        return self.cache.items()

    def __str__(self):
        pairs = []
        for k, v in self.cache.items():
            pairs.append(f"{k}: {v}")
        p = ", ".join(pairs)
        return f"<LRUCache({self.capacity}) {{{p}}}>"
