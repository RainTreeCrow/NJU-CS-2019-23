import time
from collections import namedtuple


class CacheItem:
    ''' 作为 cache 的一个表项 '''
    def __init__(self, interface):
        self.interface = interface
        self.timestamp = time.time()

    def refresh(self):
        self.timestamp = time.time()

    def __str__(self):
        ''' 只需了解：简单来说是为了让这个类被 print 出来,
        其实是在调用 str() 函数时起作用
        '''
        return f"<{self.interface}, {self.timestamp: .2f}>"


class TimeoutCache:
    ''' Timeout cache '''
    def __init__(self, timeout=10):
        ''' initiate the cache with timeout (seconds)'''
        self.cache = {}
        self.timeout = timeout  # seconds

    def notExpired(self, mac):
        ''' return True if mac address hasn't expired '''
        return time.time() - self.cache[mac].timestamp < self.timeout

    def __getitem__(self, mac):
        ''' “重载”字典的[]（但本质是其实是因为 [] 是语法糖 sytactic sugar）
        如果有一个字典：
            cache = {123: 456}
        以下两句等价：
            cache[123]
            cache.__getitem__(123)
        尽管字典的 value 存的是一个 CacheItem，但只返回其中的 interface 属性
        '''
        if mac in self.cache and self.notExpired(mac):
            # hit cache
            self.cache[mac].refresh()
            return self.cache[mac].interface
        return None  # mac address doesn't exist or has expired


    def __setitem__(self, mac, interface):
        ''' “重载”字典的[]（但本质是其实是因为 [] 是语法糖 syntactic sugar）
        如果有一个字典：
            cache = {}
        以下两句等价：
            cache[123] = 456
            cache.__setitem__(123, 456)
        '''
        self.cache[mac] = CacheItem(interface)

    def __contains__(self, mac):
        '''“重载”关键字“in”（但本质是也是因为语法糖）
        以下两句等价：
            if 123 in cache:
            if cache.__contains__(123):
        '''
        return mac in self.cache and self.notExpired(mac)

    def keys(self):
        return self.cache.keys()

    def values(self):
        return self.cache.values()

    def items(self):
        return self.cache.items()

    def __repr__(self):
        ''' 只需了解：简单来说是为了让这个类被 print 出来,
        其实是在调用 repr() 函数时起作用
        '''
        pairs = []
        for k, v in self.cache.items():
            pairs.append(f"{k}: {v}")
        p = ", ".join(pairs)
        return f"TimeoutCache<(timeout={self.timeout}) {{{p}}}>"
