'''
Ethernet learning switch in Python.
'''
import switchyard
from switchyard.lib.userlib import *


class BasicSwitch:
    def __init__(self, net: switchyard.llnetbase.LLNetBase):
        self.net = net
        self.interfaces = net.interfaces()
        self.macs = [intf.ethaddr for intf in self.interfaces]
        self.table = self.initTable()

    def initTable(self):
        ''' 初始化一个表，最普通的 Swich 就是个普通字典 '''
        return {}

    def broadcast(self, inPort, packet):
        for intf in self.interfaces:
            if inPort != intf.name:
                log_debug(f"Flooding packet {packet} to {intf.name}")
                self.net.send_packet(intf.name, packet)

    def handle_packet(self, recv: switchyard.llnetbase.ReceivedPacket):
        _, inPort, packet = recv
        log_debug(f"In \"{self.net.name}\" received packet <{packet}> on {inPort}")

        ethHeader: Ethernet = packet.get_header(Ethernet)
        self.table[ethHeader.src] = inPort  # save ethAddr of the port

        if ethHeader.dst in self.macs:
            log_debug("Packet intended for this switch")
        elif ethHeader.dst in self.table:
            log_debug(f"Send packet {packet} to {ethHeader.dst}")
            self.net.send_packet(self.table[ethHeader.dst], packet)
        else:
            self.broadcast(inPort, packet)

    def start(self):
        ''' start a daemon as a switch '''
        while True:
            try:
                recv = self.net.recv_packet()
            except NoPackets:
                continue
            except Shutdown:
                break

            self.handle_packet(recv)

        self.shutdown()

    def shutdown(self):
        self.net.shutdown()


def main(net):
    switch = BasicSwitch(net)
    switch.start()
