# If let me design lab2

## 基本思想

**代码复用，面向对象。**

## 实现思路

Switch 和 Table 逻辑上是两个对象。我们可以实现他们的**可插拔**。也就是说 Switch 的逻辑不需要动，根据需求替换 Table 即可。

首先实现 `BasicSwitch` 的逻辑作为基础，对应的 `table` 是个普通字典。

当需要实现有 Timeout 的 Switch 的时候，只需用一个子类 `SwitchTimeout` 继承 `BasicSwitch`，然后替换 `table` 部分为一个类 `TimeoutCache`，将 `TimeoutCache` 实现成与字典具有相同方法的类，那么 `BasicSwitch` 的所有逻辑都不需要变化。（这一思想充分利用了 Python **动态类型**的特点，只要两个类方法相同，就可以以同样的方式调用，这个设定叫 **duck typing**。）

同理，当需要实现 LRU Switch 时，也只需替换 `table` 为 `LRUCache`。但我这里隐藏了 LRUCache 的具体设计。

