'''
Ethernet learning switch in Python with timeout.
'''
from myswitch import BasicSwitch
from TimeoutCache import TimeoutCache


class SwitchTimeout(BasicSwitch):
    ''' 覆写 initTable 方法，替换成 TimeoutCache '''
    def initTable(self):
        return TimeoutCache(timeout=10)


def main(net):
    switch = SwitchTimeout(net)
    switch.start()
