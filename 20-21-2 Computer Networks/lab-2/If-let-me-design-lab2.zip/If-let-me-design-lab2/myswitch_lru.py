'''
Ethernet learning switch in Python with LRU cache
'''
from myswitch import BasicSwitch
from LRUCache import LRUCache


class SwitchLru(BasicSwitch):
    ''' 覆写 initTable 方法，替换成 LRUCache '''
    def initTable(self):
        return LRUCache(5)


def main(net):
    switch = SwitchLru(net)
    switch.start()
