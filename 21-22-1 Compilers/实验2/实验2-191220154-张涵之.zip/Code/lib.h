#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#pragma GCC diagnostic ignored "-Wincompatible-pointer-types"

typedef enum {
	INT_, FLOAT_, ID_, SEMI_, COMMA_,
	ASSIGNOP_, RELOP_,
	PLUS_, MINUS_, STAR_, DIV_,
	AND_, OR_, DOT_, NOT_, TYPE_,
	LP_, RP_, LB_, RB_, LC_, RC_,
	STRUCT_, RETURN_, IF_, ELSE_, WHILE_, COMPLEX_
} _Type;

typedef struct {
	char name[32];
	char val[32];
	int line;
	_Type type;
	struct Node* child;
	struct Node* next;
} Node;

Node* createNode(char n[], char v[], int l, _Type t);
void modifyTree(Node* cur, int cnt, ...);
void printNode(Node* cur);
void printTree(Node* root, int depth);
Node* getChild(Node* cur, int cnt);

Node* treeRoot;

#define BASIC_INT 0x0
#define BASIC_FLOAT 0x1
#define SYMTABLE_SIZE 0x3fff
#define FIELDLIST_SIZE 0x3f

typedef struct Type_* Type;
typedef struct FieldList_* FieldList;
typedef struct Symbol_* Symbol;

struct Type_ {
    enum { BASIC, ARRAY, STRUCTURE, FUNCTION, ERROR } kind;
    union {
        int basic;
        struct { Type elem; int size; } array;
        FieldList structure;
        struct { Type returnType; FieldList parameters; } function;
        int errorCode;
    } u;
};

struct FieldList_ {
    char name[32];
    Type type;
    int defineLine;
    FieldList tail;
};

struct Symbol_ {
    char name[32];
    Type type;
    int defineLine;
    Symbol hashTail;
};

Symbol* SymbolTable;

unsigned int hash_pjw(char* name_, int size_);
FieldList* creatFieldList();
Symbol* creatSymbolTable();
Type basicType(int basic_);
Type arrayType(Type elem_, int size_);
Type structType(FieldList members_);
Type funcType(Type returnType_, FieldList parameters_);
Type errorType(int errorCode_);
int isInt(Type t);
int isFloat(Type t);
FieldList newField(char* name_, Type type_, int line_);
Symbol newSymbol(char* name_, Type type_, int line_);
int equalList(FieldList l1, FieldList l2);
int equalType(Type t1, Type t2);
void insertSymbol(Symbol symbol_, Symbol* table_);
Symbol lookUpTable(char* name_, Symbol* table_);
void freeSymbol(Symbol cur);
void delTable(Symbol* table_);
void printTable(Symbol* table_);